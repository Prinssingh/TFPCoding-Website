const config = {
  menuCollapse: false,
  topMenu: false,
  rtl: false,
  mainTemplate: 'lightMode',
  loggedIn: false,
};

export default config;
