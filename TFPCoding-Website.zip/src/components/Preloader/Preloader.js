

export default function Preloader() {
	return (
		<div id="preloader">
            <div className="preloader">
                <span>pls wait</span>
                <span></span>
            </div>
        </div>
	)
}
